package kr.happyjob.study.manageuser.service;

import java.util.List;
import java.util.Map;

import kr.happyjob.study.manageuser.model.ManageuserModel;

public interface ManageuserService {
	
	List<ManageuserModel> applicantList(Map<String, Object> paramMap) throws Exception;
	
	List<ManageuserModel> bizList(Map<String, Object> paramMap) throws Exception;
	
	int applicantListCnt(Map<String, Object> paramMap) throws Exception;
	
	int bizListCnt(Map<String, Object> paramMap) throws Exception;
	
	ManageuserModel manageApplicantDetail(Map<String, Object> paramMap) throws Exception;
	
	int applicantPwReset(Map<String, Object> paramMap) throws Exception;
	
	int applicantPwReset1234(Map<String, Object> paramMap) throws Exception;
	
	int applicantInfoUpdate(Map<String, Object> paramMap) throws Exception;
	
	ManageuserModel manageBizDetail(Map<String, Object> paramMap) throws Exception;
	
	int bizInfoUpdate(Map<String, Object> paramMap) throws Exception;
	

}
