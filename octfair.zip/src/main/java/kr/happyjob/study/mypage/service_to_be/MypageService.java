package kr.happyjob.study.mypage.service_to_be;

import java.util.Map;

import kr.happyjob.study.manageuser.model.ManageuserModel;
import kr.happyjob.study.mypage.model.MypageModel;

public interface MypageService {
	
	MypageModel userDetail(Map<String, Object> paramMap) throws Exception;
	
	int updateUserInfo(Map<String, Object> paramMap) throws Exception;
	
	int updatePasswd(Map<String, Object> paramMap) throws Exception;
	
	int deleteUser(Map<String, Object> paramMap) throws Exception;
	
	MypageModel chkRegBiz(Map<String, Object> paramMap) throws Exception;
	
}
