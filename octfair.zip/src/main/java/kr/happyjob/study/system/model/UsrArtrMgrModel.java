package kr.happyjob.study.system.model;

public class UsrArtrMgrModel {
	// 사용자 번호
	private int row_num;
	// 사용자 시스템 ID 
	private String usr_sst_id;
	// 메뉴 ID 
	private String mnu_id;
	// 최초 등록 일시 
	private String fst_enlm_dtt;
	// 최초 등록자 시스템 ID 
	private String fst_rgst_sst_id;
	// 최종 수정 일시 
	private String fnl_mdfd_dtt;
	// 최종 수정자 시스템 ID 
	private String fnl_mdfr_sst_id;
	/**
	 * @return the row_num
	 */
	public int getRow_num() {
		return row_num;
	}
	/**
	 * @param row_num the row_num to set
	 */
	public void setRow_num(int row_num) {
		this.row_num = row_num;
	}
	/**
	 * @return the usr_sst_id
	 */
	public String getUsr_sst_id() {
		return usr_sst_id;
	}
	/**
	 * @param usr_sst_id the usr_sst_id to set
	 */
	public void setUsr_sst_id(String usr_sst_id) {
		this.usr_sst_id = usr_sst_id;
	}
	/**
	 * @return the mnu_id
	 */
	public String getMnu_id() {
		return mnu_id;
	}
	/**
	 * @param mnu_id the mnu_id to set
	 */
	public void setMnu_id(String mnu_id) {
		this.mnu_id = mnu_id;
	}
	/**
	 * @return the fst_enlm_dtt
	 */
	public String getFst_enlm_dtt() {
		return fst_enlm_dtt;
	}
	/**
	 * @param fst_enlm_dtt the fst_enlm_dtt to set
	 */
	public void setFst_enlm_dtt(String fst_enlm_dtt) {
		this.fst_enlm_dtt = fst_enlm_dtt;
	}
	/**
	 * @return the fst_rgst_sst_id
	 */
	public String getFst_rgst_sst_id() {
		return fst_rgst_sst_id;
	}
	/**
	 * @param fst_rgst_sst_id the fst_rgst_sst_id to set
	 */
	public void setFst_rgst_sst_id(String fst_rgst_sst_id) {
		this.fst_rgst_sst_id = fst_rgst_sst_id;
	}
	/**
	 * @return the fnl_mdfd_dtt
	 */
	public String getFnl_mdfd_dtt() {
		return fnl_mdfd_dtt;
	}
	/**
	 * @param fnl_mdfd_dtt the fnl_mdfd_dtt to set
	 */
	public void setFnl_mdfd_dtt(String fnl_mdfd_dtt) {
		this.fnl_mdfd_dtt = fnl_mdfd_dtt;
	}
	/**
	 * @return the fnl_mdfr_sst_id
	 */
	public String getFnl_mdfr_sst_id() {
		return fnl_mdfr_sst_id;
	}
	/**
	 * @param fnl_mdfr_sst_id the fnl_mdfr_sst_id to set
	 */
	public void setFnl_mdfr_sst_id(String fnl_mdfr_sst_id) {
		this.fnl_mdfr_sst_id = fnl_mdfr_sst_id;
	}
}
