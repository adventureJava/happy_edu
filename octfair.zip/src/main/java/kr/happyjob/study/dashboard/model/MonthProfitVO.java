package kr.happyjob.study.dashboard.model;




public class MonthProfitVO {

	private String order_date;
	private int month_profit;
	public String getOrder_date() {
		return order_date;
	}
	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}
	public int getMonth_profit() {
		return month_profit;
	}
	public void setMonth_profit(int month_profit) {
		this.month_profit = month_profit;
	}
	
}
