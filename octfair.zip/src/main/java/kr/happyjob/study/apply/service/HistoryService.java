package kr.happyjob.study.apply.service;

import java.util.List;
import java.util.Map;

import kr.happyjob.study.apply.model.HistoryModel;

public interface HistoryService {

	public List<HistoryModel> getApplyHistoryList(Map<String, String> paramMap) throws Exception;

	public List<HistoryModel> getApplyHistoryListByFilter(Map<String, String> paramMap) throws Exception;
	
	public List<HistoryModel> getApplyHistoryListByFilterRest(Map<String, Object> paramMap) throws Exception;
	
	public int historyListCnt(Map<String, Object> paramMap) throws Exception;

	public int cancleApply(Map<String, Object> paramMap) throws Exception;

	public void deleteResume(Map<String, Object> paramMap);

}
