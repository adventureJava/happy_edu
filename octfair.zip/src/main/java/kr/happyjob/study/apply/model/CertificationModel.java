package kr.happyjob.study.apply.model;

import java.sql.Date;

public class CertificationModel {
	private int certIdx;
	private String certName;
	private String grade;
	private String issuer;
	private Date acqDate;
	private int resIdx;
	
	public int getCertIdx() {
		return certIdx;
	}
	public void setCertIdx(int certIdx) {
		this.certIdx = certIdx;
	}
	public String getCertName() {
		return certName;
	}
	public void setCertName(String certName) {
		this.certName = certName;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getIssuer() {
		return issuer;
	}
	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}
	public Date getAcqDate() {
		return acqDate;
	}
	public void setAcqDate(Date acqDate) {
		this.acqDate = acqDate;
	}
	public int getResIdx() {
		return resIdx;
	}
	public void setResIdx(int resIdx) {
		this.resIdx = resIdx;
	}
	
	
	
	
}
