package kr.happyjob.study.apply.model;

public class SkillModel {
	private int skillIdx;
	private String skillName;
	private String skillDetail;
	private int resIdx;
	
	public int getSkillIdx() {
		return skillIdx;
	}
	public void setSkillIdx(int skillIdx) {
		this.skillIdx = skillIdx;
	}
	public String getSkillName() {
		return skillName;
	}
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	public String getSkillDetail() {
		return skillDetail;
	}
	public void setSkillDetail(String skillDetail) {
		this.skillDetail = skillDetail;
	}
	public int getResIdx() {
		return resIdx;
	}
	public void setResIdx(int resIdx) {
		this.resIdx = resIdx;
	}
	
	
}
