package kr.happyjob.study.apply.dao;

import java.util.List;
import java.util.Map;

import kr.happyjob.study.apply.model.HistoryModel;

public interface HistoryDao {

	public List<HistoryModel> getApplyHistoryList(Map<String, String> paramMap);
	
	public List<HistoryModel> getApplyHistoryListByFilter(Map<String, String> paramMap);
	
	public List<HistoryModel> getApplyHistoryListByFilterRest(Map<String, Object> paramMap);
	
	public int historyListCnt(Map<String, Object> paramMap);

	public int cancleApply(Map<String, Object> paramMap);

}
