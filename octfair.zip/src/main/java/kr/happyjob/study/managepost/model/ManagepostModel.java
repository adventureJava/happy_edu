package kr.happyjob.study.managepost.model;

public class ManagepostModel {
	
	private int postIdx;  //공고id(pk)
	private int bizIdx; //기업번호(fk)
	private String title;	//공고제목
	private String expRequired; // 경력여부
	private String expYears;  	//경력
	private String salary;		//급여
	private String workLocation;	//근무지역
	private String openings;		//모집인원
	private String posDescription;	//포지션소개
	private String duties;			//업무
	private String reqQualifications;//자격요건
	private String prefQualifications;//우대사항
	private String benefits;		//혜택 & 복지
	private String postDate;		//게시일
	private String startDate;		//시작일
	private String endDate;			//마감일
	private String hirProcess;		//채용절차
	private String appStatus;		//승인상태  Default'대기중'
	
	private String fileName; // attachImg
	private String phsycalPath;
	private String logicalPath;
	private int fileSize;
	private String fileExt;
	
	public String getPhsycalPath() {
		return phsycalPath;
	}
	public void setPhsycalPath(String phsycalPath) {
		this.phsycalPath = phsycalPath;
	}
	public String getLogicalPath() {
		return logicalPath;
	}
	public void setLogicalPath(String logicalPath) {
		this.logicalPath = logicalPath;
	}
	public int getFileSize() {
		return fileSize;
	}
	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}
	public String getFileExt() {
		return fileExt;
	}
	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}
	public int getPostIdx() {
		return postIdx;
	}
	public void setPostIdx(int postIdx) {
		this.postIdx = postIdx;
	}
	public int getBizIdx() {
		return bizIdx;
	}
	public void setBizIdx(int bizIdx) {
		this.bizIdx = bizIdx;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getExpRequired() {
		return expRequired;
	}
	public void setExpRequired(String expRequired) {
		this.expRequired = expRequired;
	}
	public String getExpYears() {
		return expYears;
	}
	public void setExpYears(String expYears) {
		this.expYears = expYears;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getWorkLocation() {
		return workLocation;
	}
	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}
	public String getOpenings() {
		return openings;
	}
	public void setOpenings(String openings) {
		this.openings = openings;
	}
	public String getPosDescription() {
		return posDescription;
	}
	public void setPosDescription(String posDescription) {
		this.posDescription = posDescription;
	}
	public String getDuties() {
		return duties;
	}
	public void setDuties(String duties) {
		this.duties = duties;
	}
	public String getReqQualifications() {
		return reqQualifications;
	}
	public void setReqQualifications(String reqQualifications) {
		this.reqQualifications = reqQualifications;
	}
	public String getPrefQualifications() {
		return prefQualifications;
	}
	public void setPrefQualifications(String prefQualifications) {
		this.prefQualifications = prefQualifications;
	}
	public String getBenefits() {
		return benefits;
	}
	public void setBenefits(String benefits) {
		this.benefits = benefits;
	}
	public String getPostDate() {
		return postDate;
	}
	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getHirProcess() {
		return hirProcess;
	}
	public void setHirProcess(String hirProcess) {
		this.hirProcess = hirProcess;
	}

	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}
	
}