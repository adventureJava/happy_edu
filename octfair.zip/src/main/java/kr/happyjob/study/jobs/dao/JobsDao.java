package kr.happyjob.study.jobs.dao;

import java.util.Map;

public interface JobsDao {

	boolean isScraped(Map<String, Object> paramMap);

	boolean isApplyed(Map<String, Object> paramMap);
	
}
