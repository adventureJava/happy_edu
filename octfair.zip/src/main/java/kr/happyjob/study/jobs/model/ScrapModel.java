package kr.happyjob.study.jobs.model;

public class ScrapModel {
	
	private int scrapIdx;
	private int postIdx;
	private String loginIdx;
	private String scrappedDate;
	
	private String postTitle; // 제목 검색할 때 필요해서 추가한 필드
	private String postExpRequired;
	private String postWorkLocation;
	private String postEndDate;
	private String postBizName;
	private String postBizIdx;
	private String postStatus;
	private boolean isApplyed;
	
	public int getScrapIdx() {
		return scrapIdx;
	}
	public void setScrapIdx(int scrapIdx) {
		this.scrapIdx = scrapIdx;
	}
	public int getPostIdx() {
		return postIdx;
	}
	public void setPostIdx(int postIdx) {
		this.postIdx = postIdx;
	}
	public String getLoginIdx() {
		return loginIdx;
	}
	public void setLoginIdx(String loginIdx) {
		this.loginIdx = loginIdx;
	}
	public String getScrappedDate() {
		return scrappedDate;
	}
	public void setScrappedDate(String scrappedDate) {
		this.scrappedDate = scrappedDate;
	}
	public String getPostTitle() {
		return postTitle;
	}
	public void setPostTitle(String postTitle) {
		this.postTitle = postTitle;
	}
	public String getPostExpRequired() {
		return postExpRequired;
	}
	public void setPostExpRequired(String postExpRequired) {
		this.postExpRequired = postExpRequired;
	}
	public String getPostWorkLocation() {
		return postWorkLocation;
	}
	public void setPostWorkLocation(String postWorkLocation) {
		this.postWorkLocation = postWorkLocation;
	}
	public String getPostEndDate() {
		return postEndDate;
	}
	public void setPostEndDate(String postEndDate) {
		this.postEndDate = postEndDate;
	}
	public String getPostBizName() {
		return postBizName;
	}
	public void setPostBizName(String postBizName) {
		this.postBizName = postBizName;
	}
	public String getPostBizIdx() {
		return postBizIdx;
	}
	public void setPostBizIdx(String postBizIdx) {
		this.postBizIdx = postBizIdx;
	}
	public String getPostStatus() {
		return postStatus;
	}
	public void setPostStatus(String postStatus) {
		this.postStatus = postStatus;
	}
	public boolean getIsApplyed() {
		return isApplyed;
	}
	public void setIsApplyed(boolean isApplyed) {
		this.isApplyed = isApplyed;
	}


	
}
