package kr.happyjob.study.jobs.model;

public class ApplyModel {
	
	private int applyIdx;  // 입사지원 번호
	private String applyDate; // 지원 날짜
	private String viewed;  // 열람 여부
	private String appStatus; // 진행 상태
	
	private int postIdx;  // 공고 번호
	private String postTitle; // 공고 제목
	
	private String loginIdx;  // 사용자(로그인) 아이디
	private int userIdx;
	private String userEmail; // 사용자 이메일
	private String userPhone; // 사용자 핸드폰 번호
	
	private int resumeIdx; // 이력서 번호
	private String resumeTitle; // 이력서 제목
	
	private String bizName; // 회사명
	
	
	
	public int getApplyIdx() {
		return applyIdx;
	}
	public void setApplyIdx(int applyIdx) {
		this.applyIdx = applyIdx;
	}
	public int getPostIdx() {
		return postIdx;
	}
	public void setPostIdx(int postIdx) {
		this.postIdx = postIdx;
	}
	public String getLoginIdx() {
		return loginIdx;
	}
	public void setLoginIdx(String loginIdx) {
		this.loginIdx = loginIdx;
	}
	public String getApplyDate() {
		return applyDate;
	}
	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}
	public String getViewed() {
		return viewed;
	}
	public void setViewed(String viewed) {
		this.viewed = viewed;
	}
	public String getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}
	public int getResumeIdx() {
		return resumeIdx;
	}
	public void setResumeIdx(int resumeIdx) {
		this.resumeIdx = resumeIdx;
	}
	public String getPostTitle() {
		return postTitle;
	}
	public void setPostTitle(String postTitle) {
		this.postTitle = postTitle;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getResumeTitle() {
		return resumeTitle;
	}
	public void setResumeTitle(String resumeTitle) {
		this.resumeTitle = resumeTitle;
	}
	public String getBizName() {
		return bizName;
	}
	public void setBizName(String bizName) {
		this.bizName = bizName;
	}
	public int getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(int userIdx) {
		this.userIdx = userIdx;
	}
	
	
}
