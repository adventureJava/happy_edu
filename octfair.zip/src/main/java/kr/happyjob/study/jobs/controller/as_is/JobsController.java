package kr.happyjob.study.jobs.controller.as_is;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/jobs/")
public class JobsController {
	
	//채용 정보
	//공고 보기(승인된 공고만 보기)
	//관리자의 채용공고 관리 - 공고 보기(승인된 공고만 보기)와 코드 같음
	@RequestMapping("posts.do")
	public String init() throws Exception {
		return "manage-post/post-list";
	}
}
