import java.util.StringTokenizer;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double d = 0.0;
		
		System.out.println(String.format("%.0f", d));
	}

}
